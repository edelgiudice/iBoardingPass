﻿Free .NET Modbus Library - Informations
=======================================

First of all
------------

Thanks a lot to everyone that decide to try my little library!

This library is released as is, with absolutely no warranty.

About me
--------

I'm an italian guy with not very experience with english language so, sorry in advance for a
lot of grammatic error that you can find in text...ALL CORRECTIONS ARE VERY APPRECIATED!!! :)

About my library
----------------

My library is completly free, you can do everythings with that...so enjoy it!!!
I've write all classes in a single .cs file in mode that you can have all functions grouped in a single
file that you can include everywhere. Naturally, if you want use a compiled version of it, a 
stand-alone .dll can be found in the release directory.

!!! IMPORTANT !!!
-----------------

All possible comments about BUGS, IMPROVEMENTS, SUGGESTS are VERY, VERY APPRECIATED!!!
Don't esitate to contact me!

